import pygame
from Player import Player
from Level import SplashScreen, Level01, Level02, EndScreen
import constants

"""
Escape From the Programming Lab
Author: Brendan Van Allen
Version: 0.2 (demo)

What's New:
- A splash screen has been added to display when the game is started.
- The game now has 2 levels, both of which are complete aside from some cosmetic changes.
- These levels contain more objects and items than before, and the key is actually hidden this time!
- An end game screen has been added.
- Fixed the bug causing items added from Openables not displaying to the screen.
- Levels and the end screen contain new sound effects.

Code Notes:
- Code has been restuctured to utilize packages. The groupings in each packge aren't necessarily final, and thorough
  comments explaining each package and it's classes will be included in the Beta.

How to Play:
- Move the player using the arrow keys
- Interact with items by getting close to them (practically touching them), and pressing Enter

Objective:
- Find the key that unlocks the door (not as easy in this version)

Known Bugs (New):
- Adding both real levels to Game's level_list causes the game to essentially break and be unplayable. The quick fix at
  this time is to just comment out one of the levels in the constructor for Game. Long hours have already been spent on
  this bug, but it will be fixed by the Beta. (Note: This is what's causing the warning about the unused import 
  statement, so this warning has to stay until this bug is resolved.)
- Some movement around certain objects that are right next to each other cause the player to teleport slightly. This
  is rare, and I believe it has to do with pygame's collision detection so this may be a 'feature' and not a bug. 
  
Previous Bugs:
- (CLOSED) Pygame must be initalized before any class definitions that contain a class member that is a sound. I believe 
  the only way to keep pygame initalization in main() is to change all of those class members into instance members, but 
  I'm not sure I want to do this, so at the moment I am leaning toward just leaving this as is. (Note: I didn't really
  fix this, but I added the specific initalization of pygame.mixer only to wherever this was occurring in the code, but
  pygame itself is initalized at game startup.)
- (FIXED) Items picked up from an Openable are correctly added to the actual item list of the player's inventory, but 
  they are not displayed in the inventory on the screen.

What's Next:
- Pretty up some of the visuals and sounds.
- Add another, even more difficult, level.
- Proper comments for everything, and any code restructuring that may be necessary.

Credits:
- The hierarchy of how the game runs (main, Game, Level) is taken directly from game_class_example.py, available at:
  http://programarcadegames.com/python_examples/show_file.php?file=game_class_example.py
- Background music from: http://www.bensound.com
- Sound effects from: https://zapsplat.com
- Images courtesy of Google.
"""


class Game(object):
    NO_INTERACT_SOUND = pygame.mixer.Sound("sounds/no_interact.wav")
    ESCAPE_SOUND = pygame.mixer.Sound("sounds/cheers.wav")

    def __init__(self):
        self.game_start = False
        self.game_over = False

        # Create the player
        self.player = Player()

        # Create the levels
        self.level_list = []
        self.level_list.append(SplashScreen(self.player))

        # BUG: Only one actual level can be in the list at a time.
        # Switch the comment between these two lines to play both.
        # self.level_list.append(Level01(self.player))
        self.level_list.append(Level02(self.player))

        self.level_list.append(EndScreen(self.player))

        # Set the current level
        self.current_level_num = 0
        self.current_level = self.level_list[self.current_level_num]
        self.player.level = self.current_level

    def process_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return True

            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.current_level_num == 0 or self.current_level_num == len(self.level_list)-1:
                    self.current_level.complete = True

            if event.type == pygame.KEYDOWN:
                # Movement keys
                if event.key == pygame.K_LEFT:
                    self.player.go_left()
                if event.key == pygame.K_RIGHT:
                    self.player.go_right()
                if event.key == pygame.K_UP:
                    self.player.go_up()
                if event.key == pygame.K_DOWN:
                    self.player.go_down()

                # Interaction keys
                if event.key == pygame.K_RETURN:
                    if self.current_level_num > 0:
                        interacted = self.player.interact()
                        if not interacted:
                            Game.NO_INTERACT_SOUND.play()

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT and self.player.change_x < 0:
                    self.player.stop_x()
                if event.key == pygame.K_RIGHT and self.player.change_x > 0:
                    self.player.stop_x()
                if event.key == pygame.K_UP and self.player.change_y < 0:
                    self.player.stop_y()
                if event.key == pygame.K_DOWN and self.player.change_y > 0:
                    self.player.stop_y()

        return False

    def run_logic(self):
        if not self.current_level.complete:
            self.current_level.update()
        else:
            # Switch to the next level, or end the game if player was on the end screen
            self.current_level_num += 1
            if self.current_level_num < len(self.level_list):
                self.current_level = self.level_list[self.current_level_num]
                self.player.level = self.current_level

                # If the player beat the game, stop the music and play victory sound
                if self.current_level_num == len(self.level_list)-1:
                    pygame.mixer_music.stop()
                    pygame.time.wait(3000)
                    Game.ESCAPE_SOUND.play()
            else:
                self.game_over = True

    def display_frame(self, screen):
        screen.fill(constants.WHITE)
        self.current_level.draw(screen)
        pygame.display.flip()


def main():
    # Initialize Pygame and set up the window
    pygame.init()

    size = [constants.SCREEN_WIDTH, constants.SCREEN_HEIGHT]
    screen = pygame.display.set_mode(size)

    pygame.display.set_caption("Escape the Programming Lab")
    pygame.mouse.set_visible(False)

    done = False
    clock = pygame.time.Clock()

    # Create an instance of the Game class
    game = Game()

    # Start the music and don't let it stop
    pygame.mixer_music.load("sounds/scifi.mp3")
    pygame.mixer_music.set_volume(0.5)
    pygame.mixer_music.play(-1)

    # Main game loop
    while not done:

        # Process events (keystrokes, mouse clicks, etc)
        done = game.process_events()

        # Update object positions, check for collisions
        game.run_logic()

        # Draw the current frame
        game.display_frame(screen)

        # Pause for the next frame
        clock.tick(120)

        if game.game_over:
            done = True

    # Close window and exit
    pygame.quit()


# Call the main function, start up the game
if __name__ == "__main__":
    main()
