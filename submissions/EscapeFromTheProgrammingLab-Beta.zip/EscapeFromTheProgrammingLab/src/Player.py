import pygame
import constants
from GameObject import Interactable, Door


class Player(pygame.sprite.Sprite):
    SPEED = 7
    WIDTH = 70
    HEIGHT = 70

    def __init__(self):
        super().__init__()

        # Load and size the player image
        self.image = pygame.image.load("images/player_up.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))
        self.image.convert_alpha()
        self.rect = self.image.get_rect()

        # Center the player on the game screen (height does not include inventory space)
        self.rect.x = constants.SCREEN_WIDTH // 2 - Player.WIDTH // 2
        self.rect.y = (constants.SCREEN_HEIGHT - Inventory.HEIGHT) // 2 - Player.HEIGHT // 2

        # Player does not move until controlled
        self.change_x = 0
        self.change_y = 0

        # Level is set in Game
        self.level = None

        # The hit box is set in each level's constructor so that its color matches the background of that level
        self.hit_box = None

        self.inventory = Inventory()

    def update(self):
        # Update the player position
        self.rect.x += self.change_x
        self.rect.y += self.change_y

        # Reset to last position if the move would put the player off the screen, or into the inventory space
        if self.rect.x < 0 or self.rect.right > constants.SCREEN_WIDTH:
            self.rect.x -= self.change_x
        if self.rect.y < 0 or self.rect.bottom > (constants.SCREEN_HEIGHT - Inventory.HEIGHT - HitBox.HIT_BUFFER):
            self.rect.y -= self.change_y

        # Reset to last position if the move would collide with an object
        object_hit_list = pygame.sprite.spritecollide(self, self.level.object_list, False)
        for obj in object_hit_list:
            # Moving right
            if self.change_x > 0:
                self.rect.right = obj.rect.left
            # Moving left
            if self.change_x < 0:
                self.rect.left = obj.rect.right
            # Moving down
            if self.change_y > 0:
                self.rect.bottom = obj.rect.top
            # Moving up
            if self.change_y < 0:
                self.rect.top = obj.rect.bottom

    def interact(self):
        # The hit box is used to determine if a player is close enough to be interacted with
        object_hit_list = pygame.sprite.spritecollide(self.hit_box, self.level.interactable_list, False)

        # Each level is setup so no two interactables are close enough to both be interacted with at the same time
        if len(object_hit_list) > 0:
            obj = object_hit_list[0]
            if isinstance(obj, Interactable):
                if type(obj) is Door:
                    door_opened = obj.interact()
                    if door_opened:
                        self.level.complete = True
                else:
                    obj.interact()

                return True

        # No objects interacted with
        return False

    def pickup(self, item):
        self.inventory.add(item)
        print(item.name + " was picked up")

        # Remove from the game screen
        self.level.object_list.remove(item)
        self.level.interactable_list.remove(item)
        self.level.all_sprites_list.remove(item)

    # Player-controlled movement:
    def go_left(self):
        self.change_x = -Player.SPEED
        self.change_y = 0
        self.image = pygame.image.load("images/player_left.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))

    def go_right(self):
        self.change_x = Player.SPEED
        self.change_y = 0
        self.image = pygame.image.load("images/player_right.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))

    def go_up(self):
        self.change_y = -Player.SPEED
        self.change_x = 0
        self.image = pygame.image.load("images/player_up.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))

    def go_down(self):
        self.change_y = Player.SPEED
        self.change_x = 0
        self.image = pygame.image.load("images/player_down.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))

    def stop_x(self):
        self.change_x = 0

    def stop_y(self):
        self.change_y = 0


class HitBox(pygame.sprite.Sprite):
    # Represents how far from each edge of the player that objects can be detected
    HIT_BUFFER = 5

    def __init__(self, player, level_background):
        super().__init__()

        # Create the surface
        width = Player.WIDTH + HitBox.HIT_BUFFER * 2
        height = Player.HEIGHT + HitBox.HIT_BUFFER * 2
        self.image = pygame.Surface((width, height))
        self.image.fill(level_background)
        self.rect = self.image.get_rect()

        self.player = player

    def update(self):
        # Sticks to player position
        self.rect.x = self.player.rect.x - HitBox.HIT_BUFFER
        self.rect.y = self.player.rect.y - HitBox.HIT_BUFFER


class Inventory(pygame.sprite.Sprite):
    WIDTH = constants.SCREEN_WIDTH
    HEIGHT = 100
    X = 0
    Y = constants.SCREEN_HEIGHT - HEIGHT
    SLOT_X = 50
    SLOT_Y = 10
    SLOT_WIDTH = 80
    SLOT_HEIGHT = 80
    SLOT_SPACING = 100

    def __init__(self):
        super().__init__()

        self.items = []
        self.slot_index = 0

        # Background image
        self.image = pygame.Surface((Inventory.WIDTH, Inventory.HEIGHT))
        self.image.fill(constants.BLACK)
        self.rect = self.image.get_rect()
        self.rect.x = Inventory.X
        self.rect.y = Inventory.Y

        # Slot images
        for i in range(9):
            slot = pygame.Surface((Inventory.SLOT_WIDTH, Inventory.SLOT_HEIGHT))
            slot.fill(constants.DARK_GREY)
            self.image.blit(slot, (Inventory.SLOT_X + i * Inventory.SLOT_SPACING, Inventory.SLOT_Y))

    def add(self, item):
        self.items.append(item)

        # Add item image to inventory surface
        item.image = pygame.transform.scale(item.image, [Inventory.SLOT_WIDTH, Inventory.SLOT_HEIGHT])
        item.rect = item.image.get_rect()
        item.rect.x = Inventory.SLOT_X + self.slot_index * Inventory.SLOT_SPACING
        item.rect.y = Inventory.SLOT_Y
        self.image.blit(item.image, item.rect)

        # Increase index so the next item is added to the next slot
        self.slot_index += 1

    def remove(self, item):
        self.items.remove(item)

    # Combines the two items given into the item they combine to
    # If the items don't combine, they remain in the inventory
    # def combine(self, item1, item2):
    #     are_combinable = type(item1) is Combinable and type(item2) is Combinable
    #     combine_with_eachother = item1.combines_with is item2
    #     if are_combinable and combine_with_eachother:
    #         new_item = item1.combines_to
    #         self.remove(item1)
    #         self.remove(item2)
    #         self.add(new_item)
    #     else:
    #         print("DO NOT COMBINE") ##########
    #         return None
