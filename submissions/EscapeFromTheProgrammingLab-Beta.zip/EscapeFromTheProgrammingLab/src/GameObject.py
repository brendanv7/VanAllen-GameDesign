import pygame
import constants


class GameObject(pygame.sprite.Sprite):
    def __init__(self, name, position, image_file, size):
        super().__init__()

        self.name = name
        self.position = position
        self.image = pygame.image.load(image_file)

        # Resize the image
        self.image = pygame.transform.scale(self.image, size)
        self.image.convert_alpha()

        # Set the position
        self.rect = self.image.get_rect()
        self.rect.x = position[0]
        self.rect.y = position[1]


class Interactable(GameObject):
    def __init__(self, name, position, image_file, size, player):
        super().__init__(name, position, image_file, size)
        self.player = player

    # This method should be overwritten in each subclass to peform the specific function required by that class
    def interact(self):
        print("Player interacted with: " + self.name)


class Openable(Interactable):
    def __init__(self, name, position, image_file, size, player, sound_file, item=None):
        super().__init__(name, position, image_file, size, player)

        self.sound = pygame.mixer.Sound(sound_file)
        self.item = item

    def interact(self):
        # 'Opens' this object and if it contains an item, the item is put in the player's inventory
        if self.item is not None:
            self.player.pickup(self.item)
            self.item = None

        # Sound will always play when opening this object, even if there is no item inside
        self.sound.play()


class Cabinet(Openable):
    def __init__(self, position, player, item=None):
        # Make these class members?
        name = "Cabinet"
        image_file = "images/cabinet.png"
        size = (40, 80)
        sound_file = "sounds/cabinet_open.wav"
        super().__init__(name, position, image_file, size, player, sound_file, item)


class Door(Interactable):
    pygame.mixer.init()
    OPEN_SOUND = pygame.mixer.Sound("sounds/door_open.wav")

    def __init__(self, player):
        name = "Door"
        width = 100
        height = 20
        position = (constants.SCREEN_WIDTH // 2 - width // 2, 0)
        image_file = "images/door.png"
        size = (width, height)
        super().__init__(name, position, image_file, size, player)

        # Key position is updated in each level's constructor
        self.key = Item("Key", [0, 0], "images/key.png", [20, 20], player)

    def interact(self):
        # Open the door if the player has the key
        if self.key in self.player.inventory.items:
            Door.OPEN_SOUND.play()
            return True

        return False


class Safe(Openable):
    OPEN_SOUND = pygame.mixer.Sound("sounds/safe_door.wav")
    LOCKED_SOUND = pygame.mixer.Sound("sounds/locked_safe.wav")

    def __init__(self, position, player, item, combination):
        name = "Safe"
        image_file = "images/safe.png"
        size = (60, 60)
        sound_file = "sounds/lock_dial.wav"
        self.combination = combination
        self.opened = False

        super().__init__(name, position, image_file, size, player, sound_file, item)

    def interact(self):
        if not self.opened:
            # Open the safe if the player has the combination
            if self.combination in self.player.inventory.items:
                super().interact()
                pygame.time.wait(3000)
                Safe.OPEN_SOUND.play()
                self.opened = True
            else:
                Safe.LOCKED_SOUND.play()
        else:
            Safe.OPEN_SOUND.play()


class Item(Interactable):
    PICKUP_SOUND = pygame.mixer.Sound("sounds/item_pickup.wav")

    def __init__(self, name, position, image_file, size, player):
        super().__init__(name, position, image_file, size, player)

    def interact(self):
        self.player.pickup(self)
        Item.PICKUP_SOUND.play()
