import pygame
"""
Escape From the Programming Lab
Author: Brendan Van Allen
Version: 0.1 (alpha)

Version Notes (what the code does):
- The hierarchy of how the game runs (main, Game, Level) is taken directly from game_class_example.py, available at:
  http://programarcadegames.com/python_examples/show_file.php?file=game_class_example.py
- The player is able to move around the screen, and the movement is restricted to the screen space
- GameObjects are displayed to the screen
- Interactables are able to be interacted with
- Openables are able to be opened, and if they contain an item the items are added to player inventory
- Items are able to be picked up off the ground, and are displayed in the player's inventory
- Some audio cues are present, such as when opening a cabinet, picking up an item, etc.
- Plays awesome background music, courtesy of: http://www.bensound.com
- Plus a lot of other little stuff, and other things that I'm forgetting.

How to Play:
- Move the player using the arrow keys
- Interact with items by getting close to them (practically touching them), and pressing Enter

Objective:
- Find the key that unlocks the door (quite easy in this version)

Known Bugs:
- Pygame must be initalized before any class definitions that contain a class member that is a sound. I believe the only
way to keep pygame initalization in main() is to change all of those class members into instance members, but I'm
not sure I want to do this, so at the moment I am leaning toward just leaving this as is.
- Items picked up from an Openable are correctly added to the actual item list of the player's inventory, but they are
not displayed in the inventory on the screen.


What's Next:
- Add a simple start menu with game instructions
- Build out the first level with a few more objects and items. Hide the key as well.
- Add more levels
- Add special objects (like computer) which will have unique functionality (biggest piece remaining)
- Improve some of the visuals (I don't know how I've put up with the computer image for this long)

Other thoughts:
Obviously the actual game itself is not much at the moment, but this is because I chose to prioritize building the game 
logic over making the gameplay feel more complete. In terms of gameplay, the game is well short of 50% done, mainly 
because of it only being one level. In terms of game logic and design however, I'd say the game is around 70-80% 
complete. Once the rest of the logic and design is complete, adding to the gameplay will simply be adding more levels
and adding the GameObject instances to them.
"""

# Pygame is initialized here due to a bug where initalizing sounds as class members causes an error if the mixer is not
# initalized prior to the class definition.
pygame.init()

# --- Global constants ---
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
LIGHT_GREY = (190, 190, 190)
DARK_GREY = (100, 100, 100)

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 720


# --- Classes ---
class Player(pygame.sprite.Sprite):
    SPEED = 7
    WIDTH = 70
    HEIGHT = 70

    def __init__(self):
        super().__init__()

        # Load and size the player image
        self.image = pygame.image.load("images/player_up.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))
        self.image.convert_alpha()
        self.rect = self.image.get_rect()

        # Center the player on the game screen (height does not include inventory space)
        self.rect.x = SCREEN_WIDTH // 2 - Player.WIDTH // 2
        self.rect.y = (SCREEN_HEIGHT - Inventory.HEIGHT) // 2 - Player.HEIGHT // 2

        # Player does not move until controlled
        self.change_x = 0
        self.change_y = 0

        # Level is set in Game
        self.level = None

        # The hit box is set in each level's constructor so that its color matches the background of that level
        self.hit_box = None

        self.inventory = Inventory()

    def update(self):
        # Update the player position
        self.rect.x += self.change_x
        self.rect.y += self.change_y

        # Reset to last position if the move would put the player off the screen, or into the inventory space
        if self.rect.x < 0 or self.rect.right > SCREEN_WIDTH:
            self.rect.x -= self.change_x
        if self.rect.y < 0 or self.rect.bottom > (SCREEN_HEIGHT - Inventory.HEIGHT - HitBox.HIT_BUFFER):
            self.rect.y -= self.change_y

        # Reset to last position if the move would collide with an object
        object_hit_list = pygame.sprite.spritecollide(self, self.level.object_list, False)
        for obj in object_hit_list:
            # Moving right
            if self.change_x > 0:
                self.rect.right = obj.rect.left
            # Moving left
            if self.change_x < 0:
                self.rect.left = obj.rect.right
            # Moving down
            if self.change_y > 0:
                self.rect.bottom = obj.rect.top
            # Moving up
            if self.change_y < 0:
                self.rect.top = obj.rect.bottom

    def interact(self):
        # The hit box is used to determine if a player is close enough to be interacted with
        object_hit_list = pygame.sprite.spritecollide(self.hit_box, self.level.object_list, False)

        # Each level is setup so no two items are close enough to both be interacted with at the same time
        if len(object_hit_list) > 0:
            obj = object_hit_list[0]
            if isinstance(obj, Interactable):
                if type(obj) is Door:
                    door_opened = obj.interact()
                    if door_opened:
                        self.level.complete = True
                else:
                    obj.interact()

                return True

        # No objects interacted with
        return False

    def pickup(self, item):
        self.inventory.add(item)
        print(item.name + " was picked up")

        # Remove from the game screen
        self.level.object_list.remove(item)
        self.level.all_sprites_list.remove(item)

    # Player-controlled movement:
    def go_left(self):
        self.change_x = -Player.SPEED
        self.change_y = 0
        self.image = pygame.image.load("images/player_left.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))

    def go_right(self):
        self.change_x = Player.SPEED
        self.change_y = 0
        self.image = pygame.image.load("images/player_right.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))

    def go_up(self):
        self.change_y = -Player.SPEED
        self.change_x = 0
        self.image = pygame.image.load("images/player_up.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))

    def go_down(self):
        self.change_y = Player.SPEED
        self.change_x = 0
        self.image = pygame.image.load("images/player_down.png")
        self.image = pygame.transform.scale(self.image, (Player.WIDTH, Player.HEIGHT))

    def stop_x(self):
        self.change_x = 0

    def stop_y(self):
        self.change_y = 0


class HitBox(pygame.sprite.Sprite):
    # Represents how far from each edge of the player that objects can be detected
    HIT_BUFFER = 5

    def __init__(self, player, level_background):
        super().__init__()

        # Create the surface
        width = Player.WIDTH + HitBox.HIT_BUFFER * 2
        height = Player.HEIGHT + HitBox.HIT_BUFFER * 2
        self.image = pygame.Surface((width, height))
        self.image.fill(level_background)
        self.rect = self.image.get_rect()

        self.player = player

    def update(self):
        # Sticks to player position
        self.rect.x = self.player.rect.x - HitBox.HIT_BUFFER
        self.rect.y = self.player.rect.y - HitBox.HIT_BUFFER


class Inventory(pygame.sprite.Sprite):
    WIDTH = SCREEN_WIDTH
    HEIGHT = 100
    X = 0
    Y = SCREEN_HEIGHT - HEIGHT
    SLOT_X = 50
    SLOT_Y = 10
    SLOT_WIDTH = 80
    SLOT_HEIGHT = 80
    SLOT_SPACING = 100

    def __init__(self):
        super().__init__()

        self.items = []
        self.slot_index = 0

        # Background image
        self.image = pygame.Surface((Inventory.WIDTH, Inventory.HEIGHT))
        self.image.fill(BLACK)
        self.rect = self.image.get_rect()
        self.rect.x = Inventory.X
        self.rect.y = Inventory.Y

        # Slot images
        for i in range(9):
            slot = pygame.Surface((Inventory.SLOT_WIDTH, Inventory.SLOT_HEIGHT))
            slot.fill(DARK_GREY)
            self.image.blit(slot, (Inventory.SLOT_X + i * Inventory.SLOT_SPACING, Inventory.SLOT_Y))

    def add(self, item):
        self.items.append(item)

        # Add item image to inventory surface
        # BUG: Items added from an Openable do not display in the inventory, but are added to the item list
        item.image = pygame.transform.scale(item.image, [Inventory.SLOT_WIDTH, Inventory.SLOT_HEIGHT])
        item.rect.x = Inventory.SLOT_X + self.slot_index * Inventory.SLOT_SPACING
        item.rect.y = Inventory.SLOT_Y
        self.image.blit(item.image, item.rect)

    def remove(self, item):
        self.items.remove(item)

    # Combines the two items given into the item they combine to
    # If the items don't combine, they remain in the inventory
    # def combine(self, item1, item2):
    #     are_combinable = type(item1) is Combinable and type(item2) is Combinable
    #     combine_with_eachother = item1.combines_with is item2
    #     if are_combinable and combine_with_eachother:
    #         new_item = item1.combines_to
    #         self.remove(item1)
    #         self.remove(item2)
    #         self.add(new_item)
    #     else:
    #         print("DO NOT COMBINE") ##########
    #         return None


class Game(object):
    NO_INTERACT_SOUND = pygame.mixer.Sound("sounds/no_interact.wav")

    def __init__(self):
        self.game_over = False

        # Create the player
        self.player = Player()

        # Create the levels
        self.level_list = []
        self.level_list.append(Level01(self.player))

        # Set the current level
        self.current_level_num = 0
        self.current_level = self.level_list[self.current_level_num]
        self.player.level = self.current_level

    def process_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return True

            if event.type == pygame.MOUSEBUTTONDOWN:
                # TO DO: Add start menu functionality
                print()

            if event.type == pygame.KEYDOWN:
                # Movement keys
                if event.key == pygame.K_LEFT:
                    self.player.go_left()
                if event.key == pygame.K_RIGHT:
                    self.player.go_right()
                if event.key == pygame.K_UP:
                    self.player.go_up()
                if event.key == pygame.K_DOWN:
                    self.player.go_down()

                # Interaction keys
                if event.key == pygame.K_RETURN:
                    interacted = self.player.interact()
                    if not interacted:
                        Game.NO_INTERACT_SOUND.play()

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT and self.player.change_x < 0:
                    self.player.stop_x()
                if event.key == pygame.K_RIGHT and self.player.change_x > 0:
                    self.player.stop_x()
                if event.key == pygame.K_UP and self.player.change_y < 0:
                    self.player.stop_y()
                if event.key == pygame.K_DOWN and self.player.change_y > 0:
                    self.player.stop_y()

        return False

    def run_logic(self):
        if not self.current_level.complete:
            self.current_level.update()
        else:
            self.game_over = True
            # TO DO: Switch to next level once they're added

    def display_frame(self, screen):
        screen.fill(WHITE)

        if self.game_over:
            font = pygame.font.SysFont("serif", 25)
            text = font.render("More levels coming soon :)", True, BLACK)
            center_x = (SCREEN_WIDTH // 2) - (text.get_width() // 2)
            center_y = (SCREEN_HEIGHT // 2) - (text.get_height() // 2)
            screen.blit(text, [center_x, center_y])
        else:
            self.current_level.draw(screen)

        pygame.display.flip()


class Level(object):
    OFFSCREEN_POS = [-100, -100]

    NO_SIZE = [10, 10]

    def __init__(self, player, background):

        # Sprite lists
        self.all_sprites_list = pygame.sprite.Group()
        self.object_list = pygame.sprite.Group()

        self.player = player
        self.all_sprites_list.add(player)
        self.all_sprites_list.add(player.inventory)

        self.background = background

        self.complete = False

    def update(self):
        self.all_sprites_list.update()

    def draw(self, screen):
        screen.fill(self.background)
        self.all_sprites_list.draw(screen)


class Level01(Level):
    BACKGROUND = LIGHT_GREY

    def __init__(self, player):
        # -- Level setup --
        super().__init__(player, Level01.BACKGROUND)
        pygame.display.set_caption("Level 1")

        # -- Player setup --
        player.hit_box = HitBox(player, Level01.BACKGROUND)
        self.all_sprites_list.remove(player)
        self.all_sprites_list.add(player.hit_box)
        self.all_sprites_list.add(player)

        # -- GameObject setup --

        # - GameObjects -

        # - Items -

        # - Interactables -
        self.object_list.add(Computer([500, 100], player))

        # - Openables and respective objects -
        self.object_list.add(Cabinet([0, 0], player))
        self.object_list.add(Cabinet([0, 180], player))
        self.object_list.add(Cabinet([0, 360], player))
        self.object_list.add(Cabinet([0, 540], player))

        screwdriver = Item("Screwdriver", [-100, -100], "images/screwdriver.png", [0, 0], player)
        cabinet = Cabinet([960, 0], player, screwdriver)
        self.object_list.add(cabinet)

        self.object_list.add(Cabinet([960, 180], player))
        self.object_list.add(Cabinet([960, 360], player))
        self.object_list.add(Cabinet([960, 540], player))

        # -- Door and key --
        door = Door(player)
        door.key.rect.x = 100
        door.key.rect.y = 100
        self.object_list.add(door)
        self.object_list.add(door.key)

        self.all_sprites_list.add(self.object_list)


# TO DO: Add more levels


class GameObject(pygame.sprite.Sprite):
    def __init__(self, name, position, image_file, size):
        super().__init__()

        self.name = name
        self.position = position
        self.image = pygame.image.load(image_file)

        # Resize the image
        self.image = pygame.transform.scale(self.image, size)
        self.image.convert_alpha()

        # Set the position
        self.rect = self.image.get_rect()
        self.rect.x = position[0]
        self.rect.y = position[1]


class Interactable(GameObject):
    def __init__(self, name, position, image_file, size, player):
        super().__init__(name, position, image_file, size)
        self.player = player

    # This method should be overwritten in each subclass to peform the specific function required by that class
    def interact(self):
        print("Player interacted with: " + self.name)


class Openable(Interactable):
    def __init__(self, name, position, image_file, size, player, sound_file, item=None):
        super().__init__(name, position, image_file, size, player)

        self.sound = pygame.mixer.Sound(sound_file)
        self.item = item

    def interact(self):
        # 'Opens' this object and if it contains an item, the item is put in the player's inventory
        if self.item is not None:
            self.player.pickup(self.item)
            self.item = None

        # Sound will always play when opening this object, even if there is no item inside
        self.sound.play()


class Cabinet(Openable):
    def __init__(self, position, player, item=None):
        # Make these class members?
        name = "Cabinet"
        image_file = "images/cabinet.png"
        size = (40, 80)
        sound_file = "sounds/cabinet_open.wav"
        super().__init__(name, position, image_file, size, player, sound_file, item)


# TO DO:
class Computer(Interactable):
    def __init__(self, position, player):
        name = "Computer"
        image_file = "images/computer.png"
        size = (40, 40)
        super().__init__(name, position, image_file, size, player)

    def interact(self):
        print("Beep boop")
        # TO DO: Add a *very* simple computer interface


class Door(Interactable):
    OPEN_SOUND = pygame.mixer.Sound("sounds/door_open.wav")

    def __init__(self, player):
        name = "Door"
        width = 100
        height = 20
        position = (SCREEN_WIDTH // 2 - width // 2, 0)
        image_file = "images/door.png"
        size = (width, height)
        super().__init__(name, position, image_file, size, player)

        # Key position is updated in each level's constructor
        self.key = Item("Key", [0, 0], "images/key.png", [20, 20], player)

    def interact(self):
        # Open the door if the player has the key
        if self.key in self.player.inventory.items:
            Door.OPEN_SOUND.play()
            return True

        return False

# TO DO:
# class Puzzle(Openable):
#     def __init__(self):
#         super().__init__()


class Item(Interactable):
    PICKUP_SOUND = pygame.mixer.Sound("sounds/item_pickup.wav")

    def __init__(self, name, position, image_file, size, player):
        super().__init__(name, position, image_file, size, player)

    def interact(self):
        self.player.pickup(self)
        Item.PICKUP_SOUND.play()


# TO DO:
# class Combinable(Item):
#     def __init__(self, name, description, position=None, combines_with=None, combines_to=None):
#         super().__init__(name, description, position)
#         self.combines_with = combines_with
#         self.combines_to = combines_to


def main():
    # Initialize Pygame and set up the window
    # pygame.init()

    size = [SCREEN_WIDTH, SCREEN_HEIGHT]
    screen = pygame.display.set_mode(size)

    pygame.display.set_caption("My Game")
    pygame.mouse.set_visible(False)

    done = False
    clock = pygame.time.Clock()

    # Create an instance of the Game class
    game = Game()

    # Start the music and don't let it stop
    pygame.mixer_music.load("sounds/scifi.mp3")
    pygame.mixer_music.play(-1)

    # Main game loop
    while not done:

        # Process events (keystrokes, mouse clicks, etc)
        done = game.process_events()

        # Update object positions, check for collisions
        game.run_logic()

        # Draw the current frame
        game.display_frame(screen)

        # Pause for the next frame
        clock.tick(120)

    # Close window and exit
    pygame.quit()


# Call the main function, start up the game
if __name__ == "__main__":
    main()
